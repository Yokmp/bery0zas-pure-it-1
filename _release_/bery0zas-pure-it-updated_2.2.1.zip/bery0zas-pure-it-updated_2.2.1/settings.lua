data:extend(
{
	{
		type = "bool-setting",
		name = "bery0zas-pure-it-test-mode",
		setting_type = "startup",
		default_value = false,
		order = "z[test]-a[mode]",
		hidden = true
	},
	{
		type = "bool-setting",
		name = "bery0zas-pure-it-pollutefromboxes",
		setting_type = "startup",
		default_value = true,
		order = "a[repollute]-a[switch]",
		hidden = true
	},
	{
		type = "int-setting",
		name = "bery0zas-pure-it-amountofcollectedpollution",
		setting_type = "startup",
		default_value = 25,
		minimum_value = 0,
		maximum_value = 1000,
		order = "a[repollute]-b[amount]"
	},
	{
		type = "bool-setting",
		name = "bery0zas-pure-it-clean-pollution-runtime",
		setting_type = "startup",
		default_value = false,
		order = "a[repollute]-c[clean-runtime]"
	},
	{
		type = "int-setting",
		name = "bery0zas-pure-it-clean-pollution-interval",
		setting_type = "startup",
		default_value = 3,
		minimum_value = 1,
		maximum_value = 60,
		order = "a[repollute]-d[clean-interval]"
	},
})

if mods['bobplates'] then
	data:extend({
		{
			type = "bool-setting",
			name = "bery0zas-pure-it-integrate-bobs",
			setting_type = "startup",
			default_value = true,
			order = "b[mods]-b[bobs]-a[integrate]"
		}
	})
end

if mods['angelspetrochem'] then
	data:extend({
		{
			type = "bool-setting",
			name = "bery0zas-pure-it-integrate-angelspetrochem",
			setting_type = "startup",
			default_value = true,
			order = "b[mods]-a[angels]-a[integrate]"
		},
		{
			type = "bool-setting",
			name = "bery0zas-pure-it-leave-halite",
			setting_type = "startup",
			default_value = false,
			order = "b[mods]-a[angels]-b[recipes]"
		}
	})
end
