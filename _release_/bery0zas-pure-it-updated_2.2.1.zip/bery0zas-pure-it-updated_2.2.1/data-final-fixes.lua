require("prototypes.final-fixes.badges")

