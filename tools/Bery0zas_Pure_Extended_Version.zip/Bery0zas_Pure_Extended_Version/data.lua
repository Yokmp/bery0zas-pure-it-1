require("prototypes.items.item-subgroup")
require("prototypes.items.item")
require("prototypes.items.fluid")

require("prototypes.recipes.recipe-categories")
require("prototypes.recipes.crafting-categories")
require("prototypes.recipes.recipe-item")
require("prototypes.recipes.recipe-fluid")
require("prototypes.recipes.recipe-absorption")

require("prototypes.entities.air-absorber")
require("prototypes.entities.air-adsorber")
require("prototypes.entities.air-suction-tower")
require("prototypes.entities.sparging-column")

require("prototypes.technology")

require("prototypes.keyboard-inputs")
