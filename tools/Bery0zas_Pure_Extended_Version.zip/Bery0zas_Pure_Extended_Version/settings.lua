data:extend
{
    {
        type = "int-setting",
        name = "ticks-clean-pollution",
        setting_type = "startup",
        default_value = 3,
        minimum_value = 1,
        maximum_value = 60,
        order = "a",
    },
    {
        type = "int-setting",
        name = "amount-of-collected-pollution",
        setting_type = "startup",
        default_value = 25,
        minimum_value = 0,
        maximum_value = 1000,
        order = "b"
    },
}

