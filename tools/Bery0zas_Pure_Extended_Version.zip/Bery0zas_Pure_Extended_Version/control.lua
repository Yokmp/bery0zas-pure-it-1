---reads, destroys and creates an entity
---@param player LuaPlayer
---@param entity { name: string, inner_name: string, position: MapPosition, direction: defines.direction  }
---@param rotation integer
local function swap_entities(player, entity, rotation)
    if not player.selected then
        game.print("no selection")
        return
    end
    local old_position, quality = player.selected.position, player.selected.quality
    local surface = player.selected.surface.name
    local old_direction = entity.direction

    entity.direction = entity.direction + rotation
    if entity.direction > defines.direction.west then
        entity.direction = defines.direction.north --[[@as defines.direction]]
    elseif entity.direction < defines.direction.north then
        entity.direction = defines.direction.west --[[@as defines.direction]]
    end

    if player.selected.destroy({ player = player }) then -- or die(force?, cause?)
        if not game.surfaces[surface].can_place_entity({
                name       = entity.name,
                inner_name = entity.inner_name,
                position   = entity.position,
                direction  = entity.direction,
                force      = game.forces.player,
                -- build_check_type  = defines.build_check_type.manual
            })
        then
            game.surfaces[surface].play_sound({ path = "utility/cannot_build", position = old_position })
            player.create_local_flying_text({ text = { "", { "cant-be-rotated" } }, position = { entity.position.x + 1, entity.position.y } })
            entity.direction = old_direction
            if entity.direction == 0 or entity.direction == 8 then -- shift back normal rotations
                entity.position.x = entity.position.x + 1
            else
                entity.position.y = entity.position.y + 1
            end
        else
            game.surfaces[surface].play_sound({ path = "utility/rotated_huge", position = old_position })
        end
        game.surfaces[surface].create_entity {
            name                      = entity.name,
            inner_name                = entity.inner_name,
            position                  = entity.position,
            force                     = game.forces.player,
            direction                 = entity.direction,
            quality                   = quality,
            create_build_effect_smoke = false,
        }
    end
end


---returns the corrected positions
---@param t_entity table
---@return table
local function correct_position(t_entity)
    if t_entity.name:match("adsorber") then return t_entity end

    if t_entity.direction == defines.direction.north then
        t_entity.position.x = t_entity.position.x - 1
        t_entity.position.y = t_entity.position.y - 0
    end
    if t_entity.direction == defines.direction.east then
        t_entity.position.x = t_entity.position.x - 0
        t_entity.position.y = t_entity.position.y - 1
    end
    if t_entity.direction == defines.direction.south then
        t_entity.position.x = t_entity.position.x - 1
        t_entity.position.y = t_entity.position.y - 0
    end
    if t_entity.direction == defines.direction.west then
        t_entity.position.x = t_entity.position.x - 0
        t_entity.position.y = t_entity.position.y - 1
    end
    return t_entity
end


---rotate clockwise
---@param event EventData
script.on_event("bery0zas-rotate-right", function(event)
    local player = game.players[event.player_index] ---@diagnostic disable-line
    if not player.selected or not player.selected.name:match("bery0zas") then return end
    if player.cursor_stack then return end
    local entity = player.selected or {}

    local t_entity = {
        name = entity.name,
        inner_name = entity.type == "entity_ghost" and entity.ghost_name or entity.name,
        position = player.selected.position,
        direction = entity.direction
    }

    t_entity = correct_position(t_entity)
    swap_entities(player, t_entity, 4)
end)
---rotate CounterClockwise
---@param event EventData
script.on_event("bery0zas-rotate-left", function(event)
    local player = game.players[event.player_index] ---@diagnostic disable-line
    if not player.selected or not player.selected.name:match("bery0zas") then return end
    local entity = player.selected or {}

    local t_entity = {
        name = entity.name,
        inner_name = entity.type == "entity_ghost" and entity.ghost_name or entity.name,
        position = player.selected.position,
        direction = entity.direction
    }

    t_entity = correct_position(t_entity)
    swap_entities(player, t_entity, -4)
end)

-------------------------------------------------------------------------

local UPDATE_TICKS = settings.startup["ticks-clean-pollution"].value * 60 -- раз в N секунд
local CHUNK = 32
local setting_emission = settings.startup["amount-of-collected-pollution"].value

-- таблица с тирами очистителей
-- центр/сосед указываем напрямую
local MACHINES = {
    ["air-suction-tower-mk1"] = { center = setting_emission * 1, neighbor = setting_emission * 1 / 4 },
    ["air-suction-tower-mk2"] = { center = setting_emission * 2, neighbor = setting_emission * 2 / 4 },
    ["air-suction-tower-mk3"] = { center = setting_emission * 3, neighbor = setting_emission * 3 / 4 },
}

-- === Вспомогательные ===
local function to_chunk(pos)
    return math.floor(pos.x / CHUNK), math.floor(pos.y / CHUNK)
end

local function apply_clean(surf, cx, cy, amount)
    if amount <= 0 then return end
    local center = { x = cx * CHUNK + 16, y = cy * CHUNK + 16 }
    local cur = surf.get_pollution(center) or 0
    if cur > 0 then
        local new = math.max(0, cur - amount)
        surf.set_pollution(center, new)
    end
end

-- === Основная очистка ===
local function clean_pollution()
    if not storage.machines then return end
    for uid, rec in pairs(storage.machines) do
        local e = rec.entity
        if not (e and e.valid) then
            storage.machines[uid] = nil
        else
            local def = MACHINES[rec.name]
            if def then
                local cx, cy = to_chunk(e.position)
                local surf = e.surface

                -- центр
                apply_clean(surf, cx, cy, def.center)

                -- все соседние чанки вокруг центра (8 штук) получают одно значение neighbor
                local neighbor_offsets = {
                    { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 }, -- крест
                    { 1, 1 }, { 1, -1 }, { -1, 1 }, { -1, -1 } -- диагонали
                }

                for _, off in pairs(neighbor_offsets) do
                    apply_clean(surf, cx + off[1], cy + off[2], def.neighbor)
                end
            end
        end
    end
end

-- === Добавление/удаление машин ===
local function add_machine(e)
    if not (e and e.valid) then return end
    if MACHINES[e.name] then
        storage.machines = storage.machines or {}
        storage.machines[e.unit_number] = { entity = e, name = e.name }
    end
end

local function remove_machine(e)
    if storage.machines and e and e.valid and storage.machines[e.unit_number] then
        storage.machines[e.unit_number] = nil
    end
end

local function rebuild_machines()
    local rebuilt = {}
    for _, surface in pairs(game.surfaces) do
        for name, _ in pairs(MACHINES) do
            for _, e in pairs(surface.find_entities_filtered { name = name }) do
                rebuilt[e.unit_number] = { entity = e, name = e.name }
            end
        end
    end
    storage.machines = rebuilt
end

-- === События ===
script.on_init(function()
    storage.machines = {}
    rebuild_machines()
    script.on_nth_tick(UPDATE_TICKS, clean_pollution)
end)

script.on_load(function()
    script.on_nth_tick(UPDATE_TICKS, clean_pollution)
end)

script.on_configuration_changed(function()
    rebuild_machines()
end)

local function on_built(ev) add_machine(ev.created_entity or ev.entity) end
local function on_removed(ev) remove_machine(ev.entity) end

script.on_event(defines.events.on_built_entity, on_built)
script.on_event(defines.events.on_robot_built_entity, on_built)
script.on_event(defines.events.script_raised_built, on_built)
script.on_event(defines.events.script_raised_revive, on_built)

script.on_event(defines.events.on_player_mined_entity, on_removed)
script.on_event(defines.events.on_robot_mined_entity, on_removed)
script.on_event(defines.events.on_entity_died, on_removed)
script.on_event(defines.events.script_raised_destroy, on_removed)
