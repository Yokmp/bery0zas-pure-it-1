local mod = require("constants_bp")

data:extend
{
    {
        type = "technology",
        name = "bery0zas-air-purification-1",
        icon_size = 128,
        icon = mod.technology_path .. "air-purification-1.png",
        effects =
        {
            { type = "unlock-recipe", recipe = "air-suction-tower-mk1" },
            { type = "unlock-recipe", recipe = "air-absorber-mk1" },
            { type = "unlock-recipe", recipe = "air-adsorber-mk1" },
            { type = "unlock-recipe", recipe = "bery0zas-spray-surface" },
            { type = "unlock-recipe", recipe = "bery0zas-polluted-air" },
            { type = "unlock-recipe", recipe = "bery0zas-water-absorption" },
            { type = "unlock-recipe", recipe = "bery0zas-water-absorption-with-spraying" },
            { type = "unlock-recipe", recipe = "bery0zas-recycling-spray-surface" },
            { type = "unlock-recipe", recipe = "bery0zas-recycling-polluted-water" },
            { type = "unlock-recipe", recipe = "bery0zas-coal-adsorption" },
            { type = "unlock-recipe", recipe = "bery0zas-coal-adsorption-with-steam" }
        },
        unit =
        {
            count = 150,
            ingredients =
            {
                { "automation-science-pack", 1 },
                { "logistic-science-pack",   1 }
            },
            time = 20
        },
        prerequisites = { "advanced-material-processing", "engine" } --  "logistic-science-pack"  -- ignore 30-09-2025 10:06 --
    },
    {
        type = "technology",
        name = "bery0zas-air-purification-2",
        icon_size = 128,
        icon = mod.technology_path .. "air-purification-2.png",
        effects =
        {
            { type = "unlock-recipe", recipe = "air-suction-tower-mk2" },
            { type = "unlock-recipe", recipe = "air-absorber-mk2" },
            { type = "unlock-recipe", recipe = "sparging-column-mk1" },
            { type = "unlock-recipe", recipe = "bery0zas-adsorption-coil-mk1" },
            { type = "unlock-recipe", recipe = "bery0zas-activated-carbon" },
            { type = "unlock-recipe", recipe = "bery0zas-adsorption-coil-mk1-with-activated-carbon" },
            { type = "unlock-recipe", recipe = "bery0zas-oxygen" },
            { type = "unlock-recipe", recipe = "bery0zas-oxygen-sparged-water" },
            { type = "unlock-recipe", recipe = "bery0zas-oxygen-sparged-water-absorption" },
            { type = "unlock-recipe", recipe = "bery0zas-oxygen-sparged-water-absorption-with-spraying" },
            { type = "unlock-recipe", recipe = "bery0zas-activated-carbon-adsorption" }
        },
        unit =
        {
            count = 250,
            ingredients =
            {
                { "automation-science-pack", 1 },
                { "logistic-science-pack",   1 },
                { "chemical-science-pack",   1 }
            },
            time = 25
        },
        prerequisites = { "bery0zas-air-purification-1", "chemical-science-pack" } -- "oil-processing" -- ignore 30-09-2025 10:06 --
    },
    {
        type = "technology",
        name = "bery0zas-air-purification-3",
        icon_size = 128,
        icon = mod.technology_path .. "air-purification-3.png",
        effects =
        {
            { type = "unlock-recipe", recipe = "air-suction-tower-mk3" },
            { type = "unlock-recipe", recipe = "air-absorber-mk3" },
            { type = "unlock-recipe", recipe = "bery0zas-iron-halite-extraction" },
            { type = "unlock-recipe", recipe = "bery0zas-copper-halite-extraction" },
            { type = "unlock-recipe", recipe = "bery0zas-adsorption-coil-mk2" },
            { type = "unlock-recipe", recipe = "bery0zas-cellular-carbon" },
            { type = "unlock-recipe", recipe = "bery0zas-adsorption-coil-mk2-with-cellular-carbon" },
            { type = "unlock-recipe", recipe = "bery0zas-sodium-hydroxide" },
            { type = "unlock-recipe", recipe = "bery0zas-sodium-hydroxide-sparged-water" },
            { type = "unlock-recipe", recipe = "bery0zas-sodium-hydroxide-sparged-water-absorption" },
            { type = "unlock-recipe", recipe = "bery0zas-sodium-hydroxide-sparged-water-absorption-with-spraying" },
            { type = "unlock-recipe", recipe = "bery0zas-cellular-carbon-adsorption" }
        },
        unit =
        {
            count = 500,
            ingredients =
            {
                { "automation-science-pack", 1 },
                { "logistic-science-pack",   1 },
                { "chemical-science-pack",   1 }
            },
            time = 30
        },
        prerequisites = { "bery0zas-air-purification-2", "advanced-oil-processing" }
    },
}
