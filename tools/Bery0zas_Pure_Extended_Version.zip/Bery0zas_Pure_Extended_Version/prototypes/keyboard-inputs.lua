-- ************************************************************************************ --
-- * Mod name: "-Bery0zas_Pure_Extended_Version"                Version: "2025.09.04" * --
-- * File name: "keyboard-inputs.lua"                         Date: 05.09.2025 02:06  * --
-- ***************************** -- Created by Hoochie -- ***************************** --

local inputs =
{
    { "R",         "bery0zas-rotate-right", "rotate" },
    { "SHIFT + R", "bery0zas-rotate-left",  "reverse-rotate" },
}


for i, v in ipairs(inputs) do
    data:extend { {
        type = "custom-input",
        name = v[2],
        key_sequence = v[1],
    } }
end
