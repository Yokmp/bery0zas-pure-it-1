-- ************************************************************************************ --
-- * Mod name: "-Bery0zas_Pure_Extended_Version"                Version: "2025.09.04" * --
-- * File name: "pipe-pictures.lua"                           Date: 04.09.2025 21:42  * --
-- ***************************** -- Created by Hoochie -- ***************************** --

local mod = require("constants_bp")

local pipe_pictures_graphics =
{
    north =
    {
        filename = mod.entity_path .. "pipe-covers/hr-pipe-cover-empty.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = util.by_pixel(0, 0),
        scale = 0.5
    },
    east =
    {
        filename = mod.entity_path .. "pipe-covers/hr-pipe-cover-empty.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = util.by_pixel(0, 0),
        scale = 0.5
    },
    south =
    {
        filename = mod.entity_path .. "pipe-covers/hr-pipe-cover-south.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = util.by_pixel(0, -32),
        scale = 0.5
    },
    west =
    {
        filename = mod.entity_path .. "pipe-covers/hr-pipe-cover-empty.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = util.by_pixel(0, 0),
        scale = 0.5
    }
}

return pipe_pictures_graphics
