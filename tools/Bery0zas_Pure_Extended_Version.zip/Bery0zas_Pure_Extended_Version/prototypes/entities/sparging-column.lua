local mod = require("constants_bp")
local pipe_pictures_graphics = require("prototypes.pipe-pictures")
local level_tint = require("prototypes.level-tint")
local tiers = { "mk1" }
local recipe_tiers =
{
    {
        { type = "item", name = "iron-plate",           amount = 10 },
        { type = "item", name = "pipe",                 amount = 10 },
        { type = "item", name = "barrel",               amount = 5 },
        { type = "item", name = "engine-unit",          amount = 3 },
        { type = "item", name = "electronic-circuit",   amount = 3 },
    },
    {
        { type = "item", name = "steel-plate",      amount = 10 },
        { type = "item", name = "advanced-circuit", amount = 5 },
    },
    {
        { type = "item", name = "electric-engine-unit", amount = 1 },
        { type = "item", name = "processor-unit",       amount = 1 },
     }
}

for i, tier in ipairs(tiers) do
    local next_upgrade_name = nil
    if (i + 1) and tiers[i + 1] ~= nil then
        next_upgrade_name = "sparging-column-" .. tiers[i + 1]
    end

    data:extend
    {
        {
            type = "assembling-machine",
            name = "sparging-column-" .. tier,
            icons =
            {
                { icon = mod.icon_path .. "sparging-column.png",      icon_size = 64, },
                { icon = mod.icon_path .. "sparging-column-tint.png", icon_size = 64, tint = level_tint[tier] },
            },
            flags = { "placeable-neutral", "placeable-player", "player-creation" },
            minable = { mining_time = 0.5, result = "sparging-column-" .. tier },
            fast_replaceable_group = "sparging-column",
            max_health = 150,
            crafting_speed = 0.5 + (i - 0.5) * 1.0,
            next_upgrade = next_upgrade_name,
            corpse = "medium-remnants",
            collision_box = { { -1.4, -0.9 }, { 1.4, 0.9 } },
            selection_box = { { -1.5, -1 }, { 1.5, 1 } },
            --alert_icon_shift = util.by_pixel(-3, -12),
            --drawing_box = {{ -3.0, -6.5 }, { 3.0, 2.0 }},
            fluid_boxes =
            {
                {
                    production_type = "input",
                    pipe_picture = pipe_pictures_graphics,
                    pipe_covers = pipecoverspictures(),
                    volume = 1000,
                    pipe_connections =
                    {
                        -- {
                        --    flow_direction = "input",
                        --    direction = defines.direction.north,
                        --    position = { -1, -1.5 }
                        --},
                        {
                            flow_direction = "input",
                            direction = defines.direction.north,
                            position = { -1, -.5 },
                        },
                    },
                    secondary_draw_orders = { north = -1 }
                },
                {
                    production_type = "input",
                    pipe_picture = pipe_pictures_graphics,
                    pipe_covers = pipecoverspictures(),
                    volume = 1000,
                    pipe_connections =
                    {
                        {
                            flow_direction = "input",
                            direction = defines.direction.north,
                            position = { 1, -.5 },
                        },
                    },
                    secondary_draw_orders = { north = -1 }
                },
                {
                    production_type = "output",
                    pipe_picture = pipe_pictures_graphics,
                    pipe_covers = pipecoverspictures(),
                    volume = 1000,
                    pipe_connections =
                    {
                        {
                            flow_direction = "output",
                            direction = defines.direction.south,
                            position = { 1, .5 },
                        },
                        {
                            flow_direction = "output",
                            direction = defines.direction.south,
                            position = { -1, .5 },
                        },
                    },
                    secondary_draw_orders = { north = -1 }
                },
            },
            crafting_categories = { "bery0zas-air-filtering-sparging" },
            return_ingredients_on_change = true,
            energy_source =
            {
                type = "electric",
                usage_priority = "secondary-input",
                emissions_per_minute = { pollution = 6 * i }
            },
            energy_usage = (100 + (i - 1) * 100) .. "kW",
            heating_energy = (100 + (i - 1) * 100) .. "kW",
            surface_conditions = { { property = "pressure", min = 1000, max = 2000 } },
            module_slots = 2,
            allowed_effects = { "consumption", "speed", "pollution" },
            integration_patch_render_layer = "higher-object-above",
            match_animation_speed_to_activity = true,
            graphics_set =
            {
                animation_progress = 0,
                animation =
                {
                    east =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-east.png",
                                priority = "extra-high",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(80, -82),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-east-shadow.png",
                                priority = "medium",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(80, -82),
                                scale = 0.5
                            }
                        }
                    },
                    north =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-north.png",
                                priority = "extra-high",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(78, -72),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-north-shadow.png",
                                priority = "medium",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(78, -72),
                                scale = 0.5
                            }
                        }
                    },
                    west =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-west.png",
                                priority = "extra-high",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(80, -66),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-west-shadow.png",
                                priority = "medium",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(80, -66),
                                scale = 0.5
                            }
                        }
                    },
                    south =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-south.png",
                                priority = "extra-high",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(78, -72),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "sparging-column/hr-sparging-column-south-shadow.png",
                                priority = "medium",
                                width = 576,
                                height = 576,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(78, -72),
                                scale = 0.5
                            }
                        }
                    }
                }
            },
            open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
            close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
            working_sound =
            {
                sound = { { filename = "__base__/sound/chemical-plant-3.ogg", volume = 0.7 } },
                idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
                apparent_volume = 1.5,
            },
        },

        {
            type = "item",
            name = "sparging-column-" .. tier,
            icons =
            {
                { icon = mod.icon_path .. "sparging-column.png", icon_size = 64 },
                { icon = mod.icon_path .. "sparging-column-tint.png", icon_size = 64, tint = level_tint[tier] },
                { icon = mod.icon_path .. "badge/tier-" .. tier .. ".png", icon_size = 64 }
            },
            subgroup = mods["-Hoochie_Data_Update"] and "air-purifier-2" or "air-purifier-1",
            order = "d[sparging-column]",
            place_result = "sparging-column-" .. tier,
            stack_size = 25
        },

        {
            type = "recipe",
            name = "sparging-column-" .. tier,
            category = "bery0zas-air-filtering-machine",
            enabled = false,
            energy_required = 10.0 * i,
            ingredients = recipe_tiers[i],
            results = { { type = "item", name = "sparging-column-" .. tier, amount = 1 } }
        },
    }

    if (i > 1) then
        local recipe = util.table.deepcopy(data.raw.recipe["sparging-column-" .. tier])
        recipe.ingredients = util.table.deepcopy(recipe_tiers[i])
        table.insert(recipe.ingredients, { type = "item", name = "sparging-column-" .. tiers[i - 1], amount = 1 })
        data:extend { recipe }
    end

end
