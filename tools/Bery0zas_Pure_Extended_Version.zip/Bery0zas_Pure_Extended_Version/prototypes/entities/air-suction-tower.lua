local mod = require("constants_bp")
local pipe_pictures_graphics = require("prototypes.pipe-pictures")
local level_tint = require("prototypes.level-tint")
local setting_emission = settings.startup["amount-of-collected-pollution"].value
local tiers = { "mk1", "mk2", "mk3" }
local recipe_tiers =
{
    {
        { type = "item", name = "iron-plate",         amount = 10 },
        { type = "item", name = "pipe",               amount = 5 },
        { type = "item", name = "electronic-circuit", amount = 5 },
        { type = "item", name = "engine-unit",        amount = 5 }
    },
    {
        { type = "item", name = "steel-plate",      amount = 10 },
        { type = "item", name = "advanced-circuit", amount = 5 },
    },
    {
        { type = "fluid", name = "lubricant",            amount = 50 },
        { type = "item",  name = "electric-engine-unit", amount = 5 },
    }
}

for i, tier in ipairs(tiers) do
    local next_upgrade_name = nil
    local neighbor_emission = setting_emission * i / 4
    if (i + 1) and tiers[i + 1] ~= nil then
        next_upgrade_name = "air-suction-tower-" .. tiers[i + 1]
    end

    data:extend
    {
        {
            type = "assembling-machine",
            name = "air-suction-tower-" .. tier,
            icons =
            {
                { icon = mod.icon_path .. "suction-tower.png",      icon_size = 64 },
                { icon = mod.icon_path .. "suction-tower-tint.png", icon_size = 64, tint = level_tint[tier] }
            },
            flags = { "placeable-neutral", "placeable-player", "player-creation" },
            minable = { mining_time = 0.5, result = "air-suction-tower-" .. tier },
            fast_replaceable_group = "air-suction-tower",
            max_health = 150,
            crafting_speed = 0.25 + (i - 0.25) * 1.0,
            next_upgrade = next_upgrade_name,
            corpse = "medium-remnants",
            collision_box = { { -1.3, -1.9 }, { 1.3, 1.8 } },
            selection_box = { { -1.5, -2 }, { 1.5, 2 } },
            fluid_boxes =
            {
                {
                    production_type = "input",
                    volume = 10,
                    pipe_connections = {}
                },
                {
                    production_type = "output",
                    pipe_picture = pipe_pictures_graphics,
                    pipe_covers = pipecoverspictures(),
                    volume = 10,
                    pipe_connections =
                    {
                        {
                            flow_direction = "output",
                            direction = defines.direction.north,
                            position = { 0, -1.5 },
                        },
                    },
                }
            },
            crafting_categories = { "bery0zas-air-filtering-suction" },
            fixed_recipe = "bery0zas-polluted-air",
            energy_source =
            {
                type = "electric",
                usage_priority = "secondary-input",
                emissions_per_minute = { pollution = setting_emission * -i }
            },
            custom_tooltip_fields =
            {
                {
                    name = { "tooltip-description.neighbor-emission" },
                    value = { "tooltip-description.neighbor-emission-value", tostring(-neighbor_emission) },
                    order = 80,
                },
            },
            energy_usage = (100 + (i - 1) * 100) .. "kW",
            heating_energy = (100 + (i - 1) * 100) .. "kW",
            surface_conditions = { { property = "pressure", min = 1000, max = 2000 } },
            module_slots = i,
            allowed_effects = { "consumption", "speed", "pollution" },
            integration_patch_render_layer = "higher-object-above",
            --match_animation_speed_to_activity = true,
            always_draw_idle_animation = true,
            graphics_set =
            {
                animation_progress = 0.5,
                animation =
                {
                    east =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-east.png",
                                priority = "extra-high",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(63, -48),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-east-tint.png",
                                priority = "extra-high",
                                flags = { "mask" },
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(63, -48),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-east-shadow.png",
                                priority = "medium",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                draw_as_shadow = true,
                                shift = util.by_pixel(63, -48),
                                scale = 0.5
                            }
                        }
                    },
                    north =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-north.png",
                                priority = "extra-high",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(79, -34),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-north-tint.png",
                                priority = "extra-high",
                                flags = { "mask" },
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(79, -34),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-north-shadow.png",
                                priority = "medium",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                draw_as_shadow = true,
                                shift = util.by_pixel(79, -34),
                                scale = 0.5
                            }
                        }
                    },
                    west =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-west.png",
                                priority = "extra-high",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(64, -49),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-west-tint.png",
                                priority = "extra-high",
                                flags = { "mask" },
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(64, -49),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-west-shadow.png",
                                priority = "medium",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                draw_as_shadow = true,
                                shift = util.by_pixel(64, -49),
                                scale = 0.5
                            }
                        }
                    },
                    south =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-south.png",
                                priority = "extra-high",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(80, -31),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-south-tint.png",
                                priority = "extra-high",
                                flags = { "mask" },
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                shift = util.by_pixel(80, -31),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "suction-tower/hr-suction-tower-south-shadow.png",
                                priority = "medium",
                                width = 640,
                                height = 640,
                                frame_count = 8,
                                animation_speed = 1.0,
                                line_length = 3,
                                draw_as_shadow = true,
                                shift = util.by_pixel(80, -31),
                                scale = 0.5
                            }
                        }
                    }
                }
            },
            open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
            close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
            working_sound =
            {
                sound = { { filename = "__base__/sound/electric-furnace.ogg", volume = 0.7 } },
                idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
                apparent_volume = 1.5,
            },
            circuit_wire_max_distance = assembling_machine_circuit_wire_max_distance,
            circuit_connector = circuit_connector_definitions.create_vector
                (
                    universal_connector_template,
                    {
                        {
                            variation = 0,
                            main_offset = util.by_pixel(4.625, 12.75),
                            shadow_offset = util.by_pixel(4.625, 12.75),
                            show_shadow = true,
                        },
                        {
                            variation = 6,
                            main_offset = util.by_pixel(-54.5, -31.75),
                            shadow_offset = util.by_pixel(-54.5, -31.75),
                            show_shadow = true,
                        },
                        {
                            variation = 24,
                            main_offset = util.by_pixel(-49.25,  5.875),
                            shadow_offset = util.by_pixel(-49.25,  5.875),
                            show_shadow = true,
                        },
                        {
                            variation = 2,
                            main_offset = util.by_pixel(54.875, -36.5),
                            shadow_offset = util.by_pixel(54.875, -36.5),
                            show_shadow = true,
                        },

                    }
                ),
        },

        {
            type = "item",
            name = "air-suction-tower-" .. tier,
            icons =
            {
                { icon = mod.icon_path .. "suction-tower.png",             icon_size = 64 },
                { icon = mod.icon_path .. "suction-tower-tint.png",        icon_size = 64, tint = level_tint[tier] },
                { icon = mod.icon_path .. "badge/tier-" .. tier .. ".png", icon_size = 64 }
            },
            subgroup = mods["-Hoochie_Data_Update"] and "air-purifier-2" or "air-purifier-1",
            order = "a[air-suction-tower]",
            place_result = "air-suction-tower-" .. tier,
            stack_size = 25
        },

        {
            type = "recipe",
            name = "air-suction-tower-" .. tier,
            category = "bery0zas-air-filtering-machine",
            enabled = false,
            energy_required = 20.0 * i,
            ingredients = recipe_tiers[i],
            results = { { type = "item", name = "air-suction-tower-" .. tier, amount = 1 } }
        },
    }

    if (i > 1) then
        local recipe = util.table.deepcopy(data.raw.recipe["air-suction-tower-" .. tier])
        recipe.ingredients = util.table.deepcopy(recipe_tiers[i])
        table.insert(recipe.ingredients, { type = "item", name = "air-suction-tower-" .. tiers[i - 1], amount = 1 })
        data:extend { recipe }
    end
end
