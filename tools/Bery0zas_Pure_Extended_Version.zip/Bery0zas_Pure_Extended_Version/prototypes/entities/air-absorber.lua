local mod = require("constants_bp")
local pipe_pictures_graphics = require("prototypes.pipe-pictures")
local level_tint = require("prototypes.level-tint")
local tiers = { "mk1", "mk2", "mk3" }
local recipe_tiers =
{
    {
        { type = "item", name = "iron-plate",         amount = 10 },
        { type = "item", name = "pipe",               amount = 10 },
        { type = "item", name = "barrel",             amount = 1 },
        { type = "item", name = "engine-unit",        amount = 1 },
        { type = "item", name = "electronic-circuit", amount = 3 },
    },
    {
        { type = "item", name = "steel-plate",      amount = 10 },
        { type = "item", name = "advanced-circuit", amount = 5 },
    },
    {
        { type = "item", name = "electric-engine-unit", amount = 1 },
    }
}

for i, tier in ipairs(tiers) do
    local next_upgrade_name = nil
    if (i + 1) and tiers[i + 1] ~= nil then
        next_upgrade_name = "air-absorber-" .. tiers[i + 1]
    end

    data:extend
    {
        {
            type = "assembling-machine",
            name = "air-absorber-" .. tier,
            icons =
            {
                { icon = mod.icon_path .. "absorber.png",      icon_size = 64 },
                { icon = mod.icon_path .. "absorber-tint.png", icon_size = 64, tint = level_tint[tier] },
            },
            flags = { "placeable-neutral", "placeable-player", "player-creation" },
            minable = { mining_time = 0.5, result = "air-absorber-" .. tier },
            fast_replaceable_group = "air-absorber",
            max_health = 150,
            crafting_speed = 1 + (i - 1) * 1.5,
            next_upgrade = next_upgrade_name,
            corpse = "medium-remnants",
            collision_box = { { -1.5, -2 }, { 1.5, 2 } },
            selection_box = { { -1.5, -2 }, { 1.5, 2 } },
            fluid_boxes =
            {
                {
                    production_type = "input",
                    pipe_picture = pipe_pictures_graphics,
                    pipe_covers = pipecoverspictures(),
                    volume = 1000,
                    pipe_connections =
                    {
                        {
                            flow_direction = "input",
                            direction = defines.direction.north,
                            position = { -1, -1.5 },
                        },
                    },
                },
                {
                    production_type = "input",
                    pipe_picture = pipe_pictures_graphics,
                    pipe_covers = pipecoverspictures(),
                    volume = 1000,
                    pipe_connections =
                    {
                        {
                            flow_direction = "input",
                            direction = defines.direction.north,
                            position = { 1, -1.5 },
                        },
                    },
                },
                {
                    production_type = "output",
                    pipe_picture = pipe_pictures_graphics,
                    pipe_covers = pipecoverspictures(),
                    volume = 1000,
                    pipe_connections =
                    {
                        {
                            flow_direction = "output",
                            direction = defines.direction.south,
                            position = { 0, 1.5 },
                        },
                    },
                },
            },
            crafting_categories = { "bery0zas-air-filtering-absorption" },
            return_ingredients_on_change = true,
            energy_source =
            {
                type = "electric",
                usage_priority = "secondary-input",
                emissions_per_minute = { pollution = 6 * i }
            },
            energy_usage = (100 + (i - 1) * 100) .. "kW",
            heating_energy = (100 + (i - 1) * 100) .. "kW",
            surface_conditions = { { property = "pressure", min = 1000, max = 2000 } },
            module_slots = i,
            allowed_effects = { "consumption", "speed", "pollution" },
            integration_patch_render_layer = "lower-object-above-shadow",
            match_animation_speed_to_activity = true,
            graphics_set =
            {
                animation_progress = 0,
                animation =
                {
                    east =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-east.png",
                                priority = "extra-high",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                line_length = 1,
                                shift = util.by_pixel(31, -1),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-east-tint.png",
                                priority = "extra-high",
                                blend_mode = "normal",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(31, -1),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-east-shadow.png",
                                priority = "medium",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(31, -1),
                                scale = 0.5
                            }
                        }
                    },
                    north =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-north.png",
                                priority = "extra-high",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(32, 8),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-north-tint.png",
                                priority = "extra-high",
                                blend_mode = "normal",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(32, 8),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-north-shadow.png",
                                priority = "medium",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(32, 8),
                                scale = 0.5
                            }
                        }
                    },
                    west =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-west.png",
                                priority = "extra-high",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(31, -1),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-west-tint.png",
                                priority = "extra-high",
                                blend_mode = "normal",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(31, -1),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-west-shadow.png",
                                priority = "medium",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(31, -1),
                                scale = 0.5
                            }
                        }
                    },
                    south =
                    {
                        layers =
                        {
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-south.png",
                                priority = "extra-high",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(32, 9),
                                scale = 0.5
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-south-tint.png",
                                priority = "extra-high",
                                blend_mode = "normal",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                shift = util.by_pixel(32, 9),
                                scale = 0.5,
                                tint = level_tint[tier]
                            },
                            {
                                filename = mod.entity_path .. "absorber/hr-absorber-south-shadow.png",
                                priority = "medium",
                                width = 448,
                                height = 448,
                                frame_count = 1,
                                animation_speed = 1.0,
                                line_length = 1,
                                draw_as_shadow = true,
                                shift = util.by_pixel(32, 9),
                                scale = 0.5
                            }
                        }
                    }
                }
            },
            open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
            close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
            working_sound =
            {
                sound = { { filename = "__base__/sound/heat-exchanger.ogg", volume = 0.7 } },
                idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
                apparent_volume = 1.5,
            }
        },

        {
            type = "item",
            name = "air-absorber-" .. tier,
            icons =
            {
                { icon = mod.icon_path .. "absorber.png", icon_size = 64 },
                { icon = mod.icon_path .. "absorber-tint.png", icon_size = 64, tint = level_tint[tier] },
                { icon = mod.icon_path .. "badge/tier-" .. tier .. ".png", icon_size = 64 }
            },
            subgroup = mods["-Hoochie_Data_Update"] and "air-purifier-2" or "air-purifier-1",
            order = "c[air-absorber]",
            place_result = "air-absorber-" .. tier,
            stack_size = 25
        },

        {
            type = "recipe",
            name = "air-absorber-" .. tier,
            category = "bery0zas-air-filtering-machine",
            enabled = false,
            energy_required = 20.0 * i,
            ingredients = recipe_tiers[i],
            results = { { type = "item", name = "air-absorber-" .. tier, amount = 1 } }
        },
    }

    if (i > 1) then
        local recipe = util.table.deepcopy(data.raw.recipe["air-absorber-" .. tier])
        recipe.ingredients = util.table.deepcopy(recipe_tiers[i])
        table.insert(recipe.ingredients, { type = "item", name = "air-absorber-" .. tiers[i - 1], amount = 1 })
        data:extend { recipe }
    end

end
