local mod = require("constants_bp")

data:extend
{
    {
        type = "item-group",
        name = "air-recycling",
        icon = mod.group_path .."air-recycling.png",
        icon_size = 256,
        order = "z[air-recycling]"
    },
    {
        type = "item-subgroup", -- for all air purifier
        name = "air-purifier-1",
        group = "air-recycling",
        order = "f-0"
    },
    {
        type = "item-subgroup", -- for all items
        name = "air-filters-1",
        group = "air-recycling",
        order = "f-1"
    },
    {
        type = "item-subgroup", -- for all filters
        name = "air-filters-2",
        group = "air-recycling",
        order = "f-2"
    },
    {
        type = "item-subgroup",
        name = "fluid-air-filtering",
        group = "air-recycling",
        order = "f-3"
    },
    {
        type = "item-subgroup", -- for all air filters
        name = "fluid-air-filtering-2",
        group = "air-recycling",
        order = "f-4"
    },
}