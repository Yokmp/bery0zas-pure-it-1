local mod = require("constants_bp")
local ICON_FILTER = mod.icon_path .. "badge/icon-air-cleaning.png"

data:extend
{
     --[[ add ignore block 05-09-2025 03:28 --
     {
     	type = "fluid",
     	name = "bery0zas-pollution",
     	default_temperature = 15,
     	max_temperature = 100,
     	gas_temperature = 0,
     	base_color = { r = 0.1, g = 0.05, b = 0.05 },
     	flow_color = { r = 0.1, g = 0.05, b = 0.05 },
     	icons = { {	icon = mod.icon_path .. "fluid/pollution.png", icon_size = 64 } },
     	auto_barrel = false
     }, --]]

    {
        type = "fluid",
        name = "bery0zas-polluted-air",
        subgroup = "fluid-air-filtering",
        order = "e[polluted-air]",
        default_temperature = 15,
        max_temperature = 100,
        gas_temperature = 0,
        base_color = { r = 0.1, g = 0.05, b = 0.05 },
        flow_color = { r = 0.1, g = 0.05, b = 0.05 },
        icons =
        {
            { icon = mod.icon_path .. "fluid/pollution.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        auto_barrel = true
    },

    {
        type = "fluid",
        name = "bery0zas-polluted-water",
        subgroup = "fluid-air-filtering",
        order = "f[polluted-water]",
        default_temperature = 15,
        max_temperature = 100,
        base_color = { r = 0.06, g = 0.2, b = 0.22 },
        flow_color = { r = 0.06, g = 0.2, b = 0.22 },
        icons =
        {
            { icon = mod.icon_path .. "fluid/polluted-water.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        auto_barrel = true
    },

    {
        type = "fluid",
        name = "bery0zas-oxygen",
        subgroup = "fluid-air-filtering",
        order = "a[oxygen]",
        default_temperature = 15,
        max_temperature = 100,
        gas_temperature = 0,
        base_color = { r = 0.98, g = 0.1, b = 0.1 },
        flow_color = { r = 0.98, g = 0.1, b = 0.1 },
        icons =
        {
            { icon = mod.icon_path .. "fluid/oxygen.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        auto_barrel = true
    },

    {
        type = "fluid",
        name = "bery0zas-oxygen-sparged-water",
        subgroup = "fluid-air-filtering",
        order = "b[oxygen-sparged-water]",
        default_temperature = 15,
        max_temperature = 100,
        base_color = { r = 0.62, g = 0.7, b = 0.95 },
        flow_color = { r = 0.62, g = 0.7, b = 0.95 },
        icons =
        {
            { icon = mod.icon_path .. "fluid/oxygen-sparged-water.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        auto_barrel = true
    },

    {
        type = "fluid",
        name = "bery0zas-sodium-hydroxide",
        subgroup = "fluid-air-filtering",
        order = "c[sodium-hydroxide]",
        default_temperature = 15,
        max_temperature = 100,
        gas_temperature = 0,
        base_color = { r = 0.96, g = 0.98, b = 1.0 },
        flow_color = { r = 0.96, g = 0.98, b = 1.0 },
        icons =
        {
            { icon = mod.icon_path .. "fluid/sodium-hydroxide.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        auto_barrel = true
    },

    {
        type = "fluid",
        name = "bery0zas-sodium-hydroxide-sparged-water",
        subgroup = "fluid-air-filtering",
        order = "d[sodium-hydroxide-sparged-water]",
        default_temperature = 15,
        max_temperature = 100,
        base_color = { r = 0.87, g = 0.7, b = 0.95 },
        flow_color = { r = 0.87, g = 0.7, b = 0.95 },
        icons =
        {
            { icon = mod.icon_path .. "fluid/sodium-hydroxide-sparged-water.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        auto_barrel = true
    }
}
