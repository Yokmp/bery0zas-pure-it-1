local mod = require("constants_bp")
local GRAPHICS_ICON = mod.icon_path .. "badge/"

data:extend
{

    {
        type = "item",
        name = "bery0zas-halite",
        icons = { { icon = mod.icon_path .. "halite.png", icon_size = 64 } },
        subgroup = "raw-resource",
        stack_size = 100,
        order = "h[halite]"
    },

    {
        type = "item",
        name = "bery0zas-activated-carbon",
        icons = { { icon = mod.icon_path .. "activated-carbon.png", icon_size = 64 } },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-1",
        order = "a[carbon]-a[activated-carbon]",
        stack_size = 100
    },

    {
        type = "item",
        name = "bery0zas-cellular-carbon",
        icons = { { icon = mod.icon_path .. "cellular-carbon.png", icon_size = 64 } },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-1",
        order = "a[carbon]-b[activated-carbon]",
        stack_size = 100
    },

    {
        type = "item",
        name = "bery0zas-spray-surface",
        icons = { { icon = mod.icon_path .. "spray-surface.png", icon_size = 64 } },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-1",
        order = "b[spray-surface]-a[spray-surface]",
        stack_size = 100,
    },

    {
        type = "item",
        name = "bery0zas-polluted-spray-surface",
        icons = { { icon = mod.icon_path .. "polluted-spray-surface.png", icon_size = 64 } },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-1",
        order = "b[spray-surface]-b[polluted-spray-surface]",
        stack_size = 100
    },

    {
        type = "item",
        name = "bery0zas-adsorption-coil-mk1",
        icons =
        {
            { icon = mod.icon_path .. "adsorption-coil-mk1.png", icon_size = 64 },
            { icon = GRAPHICS_ICON .. "tier-mk1.png", icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-2",
        order = "c[coil]-a[adsorption-coil-mk1]",
        stack_size = 100
    },

    {
        type = "item",
        name = "bery0zas-adsorption-coil-mk2",
        icons =
        {
            { icon = mod.icon_path .. "adsorption-coil-mk2.png", icon_size = 64 },
            { icon = GRAPHICS_ICON .. "tier-mk2.png", icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-2",
        order = "d[coil]-a[adsorption-coil-mk2]",
        stack_size = 100
    },

    {
        type = "item",
        name = "bery0zas-adsorption-coil-mk1-with-activated-carbon",
        icons =
        {
            { icon = mod.icon_path .. "adsorption-coil-mk1-with-activated-carbon.png", icon_size = 64 },
            { icon = GRAPHICS_ICON .. "tier-mk1.png", icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-2",
        order = "c[coil]-b[adsorption-coil-mk1-with-activated-carbon]",
        stack_size = 100
    },

    {
        type = "item",
        name = "bery0zas-adsorption-coil-mk2-with-cellular-carbon",
        icons =
        {
            { icon = mod.icon_path .. "adsorption-coil-mk2-with-cellular-carbon.png", icon_size = 64 },
            { icon = GRAPHICS_ICON .. "tier-mk2.png", icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-4" or "air-filters-2",
        order = "d[coil]-b[adsorption-coil-mk2-with-cellular-carbon]",
        stack_size = 100
    },
}
