-- ************************************************************************************ --
-- * Mod name: "-Bery0zas_Pure_Extended_Version"                Version: "2025.09.04" * --
-- * File name: "recipe-categories.lua"                       Date: 05.09.2025 01:43  * --
-- ***************************** -- Created by Hoochie -- ***************************** --

data:extend
{
    { type = "recipe-category", name = "bery0zas-air-filtering-machine" },
    { type = "recipe-category", name = "bery0zas-air-filtering-item" },
    { type = "recipe-category", name = "bery0zas-air-filtering-suction" },
    { type = "recipe-category", name = "bery0zas-air-filtering-sparging" },
    { type = "recipe-category", name = "bery0zas-air-filtering-chemistry" },
    { type = "recipe-category", name = "bery0zas-air-filtering-absorption" },
    { type = "recipe-category", name = "bery0zas-air-filtering-adsorption" },
    { type = "recipe-category", name = "bery0zas-air-filtering-burning" }
}
