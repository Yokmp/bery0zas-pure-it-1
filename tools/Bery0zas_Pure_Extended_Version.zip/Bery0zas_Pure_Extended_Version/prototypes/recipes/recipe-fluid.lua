-- ************************************************************************************ --
-- * Mod name: "!my"                                                  Version: "mods" * --
-- * File name: "recipe-fluid.lua"                            Date: 04.09.2025 17:44  * --
-- ***************************** -- Created by Hoochie -- ***************************** --

local mod = require("constants_bp")
local GRAPHICS_ICON = mod.icon_path .. ""
local ICON_FILTER = mod.icon_path .. "badge/icon-air-cleaning.png"

data:extend
{

    {
        type = "recipe",
        name = "bery0zas-polluted-air",
        icons =
        {
            { icon = "__base__/graphics/icons/fluid/steam.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "air-filters-2",
        energy_required = 1,
        category = "bery0zas-air-filtering-suction",
        enabled = false,
        -- ingredients = { { type = "fluid", name = "bery0zas-pollution", amount = 1, fluidbox_index = 1 } },
        results = { { type = "fluid", name = "bery0zas-polluted-air", amount = 1 } },
        main_product = "bery0zas-polluted-air"
    },

    {
        type = "recipe",
        name = "bery0zas-oxygen",
        icons =
        {
            { icon = GRAPHICS_ICON .. "fluid/oxygen.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "fluid-air-filtering" or "fluid-air-filtering",
        energy_required = 10,
        category = "bery0zas-air-filtering-chemistry",
        enabled = false,
        ingredients = {},
        surface_conditions = { { property = "pressure", min = 1000, max = 2000 } },
        results = { { type = "fluid", name = "bery0zas-oxygen", amount = 2 } },
        main_product = "bery0zas-oxygen"
    },

    {
        type = "recipe",
        name = "bery0zas-oxygen-sparged-water",
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/oxygen-sparging.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "fluid-air-filtering" or "fluid-air-filtering",
        energy_required = 20,
        category = "bery0zas-air-filtering-sparging",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "water",           amount = 10 },
            { type = "fluid", name = "bery0zas-oxygen", amount = 10 }
        },
        results = { { type = "fluid", name = "bery0zas-oxygen-sparged-water", amount = 20 } },
        main_product = "bery0zas-oxygen-sparged-water"
    },

    {
        type = "recipe",
        name = "bery0zas-sodium-hydroxide",
        icons =
        {
            { icon = GRAPHICS_ICON .. "fluid/sodium-hydroxide.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "fluid-air-filtering" or "fluid-air-filtering",
        energy_required = 10,
        category = "bery0zas-air-filtering-chemistry",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "water",           amount = 30 },
            { type = "item",  name = "bery0zas-halite", amount = 3 }
        },
        results = { { type = "fluid", name = "bery0zas-sodium-hydroxide", amount = 30 } },
        main_product = "bery0zas-sodium-hydroxide"
    },

    {
        type = "recipe",
        name = "bery0zas-sodium-hydroxide-sparged-water",
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/sodium-hydroxide-sparging.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "fluid-air-filtering" or "fluid-air-filtering",
        energy_required = 20,
        category = "bery0zas-air-filtering-sparging",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "water",                     amount = 10 },
            { type = "fluid", name = "bery0zas-sodium-hydroxide", amount = 10 }
        },
        results = { { type = "fluid", name = "bery0zas-sodium-hydroxide-sparged-water", amount = 20 } },
        main_product = "bery0zas-sodium-hydroxide-sparged-water"
    },

}