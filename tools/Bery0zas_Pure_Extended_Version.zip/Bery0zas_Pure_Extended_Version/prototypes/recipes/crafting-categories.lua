-- ************************************************************************************ --
-- * Mod name: "-Bery0zas_Pure_Extended_Version"                Version: "2025.09.04" * --
-- * File name: "crafting-categories.lua"                     Date: 05.09.2025 01:56  * --
-- ***************************** -- Created by Hoochie -- ***************************** --

-- Список объектов и категорий
local add_categories =
{
    ["character"] = { ["character"] = { "bery0zas-air-filtering-machine" } },
    ["assembling-machine"] =
    {
        ["assembling-machine-1"] = { "bery0zas-air-filtering-machine", "bery0zas-air-filtering-item" },
        ["assembling-machine-2"] = { "bery0zas-air-filtering-machine", "bery0zas-air-filtering-item" },
        ["assembling-machine-3"] = { "bery0zas-air-filtering-machine", "bery0zas-air-filtering-item" },
        ["chemical-plant"]       = { "bery0zas-air-filtering-chemistry" },
    },
    ["furnace"] =
    {
        ["stone-furnace"]    = { "bery0zas-air-filtering-burning" },
        ["steel-furnace"]    = { "bery0zas-air-filtering-burning" },
        ["electric-furnace"] = { "bery0zas-air-filtering-burning" },
    }
}

-- Если есть мод Angels Petrochem
if mods["angelspetrochem"] then
    add_categories["assembling-machine"]["angels-chemical-plant"]     = { "bery0zas-air-filtering-chemistry" }
    add_categories["assembling-machine"]["angels-chemical-plant-2"]   = { "bery0zas-air-filtering-chemistry" }
    add_categories["assembling-machine"]["angels-chemical-plant-3"]   = { "bery0zas-air-filtering-chemistry" }
    add_categories["assembling-machine"]["angels-chemical-plant-4"]   = { "bery0zas-air-filtering-chemistry" }
    add_categories["assembling-machine"]["advanced-chemical-plant"]   = { "bery0zas-air-filtering-chemistry" }
    add_categories["assembling-machine"]["advanced-chemical-plant-2"] = { "bery0zas-air-filtering-chemistry" }
end

-- Добавляем категории циклом
for object_type, objects in pairs(add_categories) do
    for object_name, categories in pairs(objects) do
        for _, category in ipairs(categories) do
            table.insert(data.raw[object_type][object_name].crafting_categories, category)
        end
    end
end
