-- ************************************************************************************ --
-- * Mod name: "!my"                                                  Version: "mods" * --
-- * File name: "recipe-item.lua"                             Date: 04.09.2025 17:33  * --
-- ***************************** -- Created by Hoochie -- ***************************** --

local mod = require("constants_bp")
local GRAPHICS_ICON = mod.icon_path .. ""
local ICON_RECYCLING = mod.icon_path .. "badge/recycling-badge.png"

data:extend
{

    {
        type = "recipe",
        name = "bery0zas-activated-carbon",
        icons = { { icon = GRAPHICS_ICON .. "activated-carbon.png", icon_size = 64 } },
        energy_required = 10,
        category = "bery0zas-air-filtering-chemistry",
        enabled = false,
        ingredients =
        {
            { type = "item",  name = "coal",          amount = 10 },
            { type = "fluid", name = "sulfuric-acid", amount = 20 }
        },
        results = { { type = "item", name = "bery0zas-activated-carbon", amount = 8 } }
    },

    {
        type = "recipe",
        name = "bery0zas-cellular-carbon",
        icons = { { icon = GRAPHICS_ICON .. "cellular-carbon.png", icon_size = 64 } },
        energy_required = 10,
        category = "bery0zas-air-filtering-chemistry",
        enabled = false,
        ingredients =
        {
            { type = "item",  name = "bery0zas-activated-carbon", amount = 10 },
            { type = "fluid", name = "petroleum-gas",             amount = 20 }
        },
        results = { { type = "item", name = "bery0zas-cellular-carbon", amount = 8 } }
    },

    {
        type = "recipe",
        name = "bery0zas-spray-surface",
        icons = { { icon = GRAPHICS_ICON .. "spray-surface.png", icon_size = 64 } },
        energy_required = 10,
        category = "bery0zas-air-filtering-item",
        enabled = false,
        ingredients =
        {
            { type = "item", name = "iron-plate", amount = 2 },
            { type = "item", name = "iron-stick", amount = 6 },
        },
        results = { { type = "item", name = "bery0zas-spray-surface", amount = 1 } }
    },

    {
        type = "recipe",
        name = "bery0zas-recycling-spray-surface",
        icons = { { icon = GRAPHICS_ICON .. "recipe/polluted-spray-surface-recycling.png", icon_size = 64 } },
        order = "b[spray-surface]-c[polluted-spray-surface]",
        energy_required = 7,
        category = "bery0zas-air-filtering-burning",
        enabled = false,
        ingredients = { { type = "item", name = "bery0zas-polluted-spray-surface", amount = 1 } },
        results = { { type = "item", name = "bery0zas-spray-surface", amount = 1 } },
        main_product = "bery0zas-spray-surface"
    },

    {
        type = "recipe",
        name = "bery0zas-adsorption-coil-mk1",
        icons = { { icon = GRAPHICS_ICON .. "adsorption-coil-mk1.png", icon_size = 64 } },
        energy_required = 10,
        category = "bery0zas-air-filtering-item",
        enabled = false,
        ingredients =
        {
            { type = "item", name = "iron-plate", amount = 3 },
            { type = "item", name = "iron-stick", amount = 8 },
        },
        results = { { type = "item", name = "bery0zas-adsorption-coil-mk1", amount = 1 } }
    },

    {
        type = "recipe",
        name = "bery0zas-adsorption-coil-mk2",
        icons = { { icon = GRAPHICS_ICON .. "adsorption-coil-mk2.png", icon_size = 64 } },
        energy_required = 10,
        category = "bery0zas-air-filtering-item",
        enabled = false,
        ingredients =
        {
            { type = "item", name = "steel-plate", amount = 3 },
            { type = "item", name = "iron-stick",  amount = 8 }
        },
        results = { { type = "item", name = "bery0zas-adsorption-coil-mk2", amount = 1 } }
    },

    {
        type = "recipe",
        name = "bery0zas-adsorption-coil-mk1-with-activated-carbon",
        icons = { { icon = GRAPHICS_ICON .. "adsorption-coil-mk1-with-activated-carbon.png", icon_size = 64 } },
        energy_required = 3,
        category = "bery0zas-air-filtering-item",
        enabled = false,
        ingredients =
        {
            { type = "item", name = "bery0zas-adsorption-coil-mk1", amount = 1 },
            { type = "item", name = "bery0zas-activated-carbon",    amount = 1 }
        },
        results = { { type = "item", name = "bery0zas-adsorption-coil-mk1-with-activated-carbon", amount = 1 } }
    },

    {
        type = "recipe",
        name = "bery0zas-adsorption-coil-mk2-with-cellular-carbon",
        icons = { { icon = GRAPHICS_ICON .. "adsorption-coil-mk2-with-cellular-carbon.png", icon_size = 64 } },
        energy_required = 6,
        category = "bery0zas-air-filtering-item",
        enabled = false,
        ingredients =
        {
            { type = "item", name = "bery0zas-adsorption-coil-mk2", amount = 1 },
            { type = "item", name = "bery0zas-cellular-carbon",     amount = 1 }
        },
        results = { { type = "item", name = "bery0zas-adsorption-coil-mk2-with-cellular-carbon", amount = 1 } }
    },

    {
        type = "recipe",
        name = "bery0zas-activated-carbon-adsorption",
        icons =
        {
            { icon = GRAPHICS_ICON .. "adsorption-coil-mk1-with-activated-carbon.png", icon_size = 64 },
            { icon = ICON_RECYCLING,                                                   icon_size = 64 },
        },
        --subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "air-filters-2",
        order = "c[coil]-c[activated-carbon-adsorption]",
        energy_required = 40,
        category = "bery0zas-air-filtering-adsorption",
        enabled = false,
        ingredients =
        {
            { type = "item",  name = "bery0zas-adsorption-coil-mk1-with-activated-carbon", amount = 1 },
            { type = "fluid", name = "bery0zas-polluted-air",                              amount = 8, fluidbox_index = 2 }
        },
        results = { { type = "item", name = "bery0zas-adsorption-coil-mk1", amount = 1 } },
        main_product = "bery0zas-adsorption-coil-mk1"
    },

    {
        type = "recipe",
        name = "bery0zas-cellular-carbon-adsorption",
        icons =
        {
            { icon = GRAPHICS_ICON .. "adsorption-coil-mk2-with-cellular-carbon.png", icon_size = 64 },
            { icon = ICON_RECYCLING,                                                  icon_size = 64 },
        },
        --subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "air-filters-2",
        order = "d[coil]-c[cellular-carbon-adsorption]",
        energy_required = 40,
        category = "bery0zas-air-filtering-adsorption",
        enabled = false,
        ingredients =
        {
            { type = "item",  name = "bery0zas-adsorption-coil-mk2-with-cellular-carbon", amount = 1 },
            { type = "fluid", name = "bery0zas-polluted-air",                             amount = 12, fluidbox_index = 2 }
        },
        results = { { type = "item", name = "bery0zas-adsorption-coil-mk2", amount = 1 } },
        main_product = "bery0zas-adsorption-coil-mk2"
    },

    {
        type = "recipe",
        name = "bery0zas-iron-halite-extraction",
        icons = { { icon = GRAPHICS_ICON .. "recipe/iron-halite-extraction.png", icon_size = 64 } },
        energy_required = 2,
        category = "bery0zas-air-filtering-item",
        enabled = false,
        ingredients = { { type = "item", name = "iron-ore", amount = 20 } },
        results =
        {
            { type = "item", name = "iron-ore",        amount = 19 },
            { type = "item", name = "bery0zas-halite", amount = 1 }
        },
        main_product = "bery0zas-halite",
    },

    {
        type = "recipe",
        name = "bery0zas-copper-halite-extraction",
        icons = { { icon = GRAPHICS_ICON .. "recipe/copper-halite-extraction.png", icon_size = 64 } },
        energy_required = 2,
        category = "bery0zas-air-filtering-item",
        enabled = false,
        ingredients = { { type = "item", name = "copper-ore", amount = 20 } },
        results =
        {
            { type = "item", name = "copper-ore",      amount = 19 },
            { type = "item", name = "bery0zas-halite", amount = 1 }
        },
        main_product = "bery0zas-halite",
    },

}
