local mod = require("constants_bp")
local GRAPHICS_ICON = mod.icon_path .. ""
local ICON_FILTER = mod.icon_path .. "badge/icon-air-cleaning.png"

data:extend
{

    {
        type = "recipe",
        name = "bery0zas-water-absorption",
        energy_required = 30,
        category = "bery0zas-air-filtering-absorption",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "water",                 amount = 2, fluidbox_index = 1 },
            { type = "fluid", name = "bery0zas-polluted-air", amount = 2, fluidbox_index = 2 }
        },
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/water-absorption.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results = { { type = "fluid", name = "bery0zas-polluted-water", amount = 4 } },
        main_product = "bery0zas-polluted-water"
    },

    {
        type = "recipe",
        name = "bery0zas-oxygen-sparged-water-absorption",
        energy_required = 20,
        category = "bery0zas-air-filtering-absorption",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "bery0zas-oxygen-sparged-water", amount = 4, fluidbox_index = 1 },
            { type = "fluid", name = "bery0zas-polluted-air",         amount = 4, fluidbox_index = 2 }
        },
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/oxygen-sparged-water-absorption.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results = { { type = "fluid", name = "bery0zas-polluted-water", amount = 8 } },
        main_product = "bery0zas-polluted-water"
    },

    {
        type = "recipe",
        name = "bery0zas-sodium-hydroxide-sparged-water-absorption",
        energy_required = 15,
        category = "bery0zas-air-filtering-absorption",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "bery0zas-sodium-hydroxide-sparged-water", amount = 12, fluidbox_index = 1 },
            { type = "fluid", name = "bery0zas-polluted-air",                   amount = 8,  fluidbox_index = 2 }
        },
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/sodium-hydroxide-sparged-water-absorption.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results = { { type = "fluid", name = "bery0zas-polluted-water", amount = 16 } },
        main_product = "bery0zas-polluted-water"
    },

    {
        type = "recipe",
        name = "bery0zas-water-absorption-with-spraying",
        energy_required = 20,
        category = "bery0zas-air-filtering-absorption",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "water",                  amount = 2, fluidbox_index = 1 },
            { type = "fluid", name = "bery0zas-polluted-air",  amount = 2, fluidbox_index = 2 },
            { type = "item",  name = "bery0zas-spray-surface", amount = 2 }
        },
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/water-absorption-with-spraying.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results =
        {
            { type = "fluid", name = "bery0zas-polluted-water",         amount = 4 },
            { type = "item",  name = "bery0zas-polluted-spray-surface", amount = 2 }
        }
    },

    {
        type = "recipe",
        name = "bery0zas-oxygen-sparged-water-absorption-with-spraying",
        energy_required = 15,
        category = "bery0zas-air-filtering-absorption",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "bery0zas-oxygen-sparged-water", amount = 4, fluidbox_index = 1 },
            { type = "fluid", name = "bery0zas-polluted-air",         amount = 4, fluidbox_index = 2 },
            { type = "item",  name = "bery0zas-spray-surface",        amount = 1 }
        },
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/oxygen-sparged-water-absorption-with-spraying.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results =
        {
            { type = "fluid", name = "bery0zas-polluted-water",         amount = 8 },
            { type = "item",  name = "bery0zas-polluted-spray-surface", amount = 1 }
        }
    },

    {
        type = "recipe",
        name = "bery0zas-sodium-hydroxide-sparged-water-absorption-with-spraying",
        energy_required = 10,
        category = "bery0zas-air-filtering-absorption",
        enabled = false,
        ingredients =
        {
            { type = "fluid", name = "bery0zas-sodium-hydroxide-sparged-water", amount = 8, fluidbox_index = 1 },
            { type = "fluid", name = "bery0zas-polluted-air",                   amount = 8, fluidbox_index = 2 },
            { type = "item",  name = "bery0zas-spray-surface",                  amount = 1 }
        },
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/sodium-hydroxide-sparged-water-absorption-with-spraying.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results =
        {
            { type = "fluid", name = "bery0zas-polluted-water",         amount = 16 },
            { type = "item",  name = "bery0zas-polluted-spray-surface", amount = 1 }
        }
    },

    {
        type = "recipe",
        name = "bery0zas-recycling-polluted-water",
        energy_required = 10,
        category = "bery0zas-air-filtering-chemistry",
        enabled = false,
        ingredients = { { type = "fluid", name = "bery0zas-polluted-water", amount = 20 } },
        icons =
        {
            { icon = GRAPHICS_ICON .. "recipe/polluted-water-recycling.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        order = "z[polluted-water-recycling]",
        results =
        {
            { type = "fluid", name = "water",      amount = 15 },
            { type = "fluid", name = "crude-oil",  probability = 0.05, amount = 20 },
            { type = "item",  name = "coal",       probability = 0.05, amount = 2 },
            { type = "item",  name = "iron-ore",   probability = 0.05, amount = 2 },
            { type = "item",  name = "copper-ore", probability = 0.05, amount = 2 }
        }
    },

    {
        type = "recipe",
        name = "bery0zas-coal-adsorption",
        energy_required = 40,
        category = "bery0zas-air-filtering-adsorption",
        enabled = false,
        ingredients =
        {
            { type = "item",  name = "coal",                  amount = 1 },
            { type = "fluid", name = "bery0zas-polluted-air", amount = 3, fluidbox_index = 2 }
        },
        icons =
        {
            { icon = "__base__/graphics/icons/coal.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results = {}
    },

    {
        type = "recipe",
        name = "bery0zas-coal-adsorption-with-steam",
        energy_required = 40,
        category = "bery0zas-air-filtering-adsorption",
        enabled = false,
        ingredients =
        {
            { type = "item",  name = "coal",                  amount = 2 },
            { type = "fluid", name = "steam",                 amount = 3, fluidbox_index = 1 },
            { type = "fluid", name = "bery0zas-polluted-air", amount = 5, fluidbox_index = 2 }
        },
        icons =
        {
            { icon = "__base__/graphics/icons/fluid/steam.png", icon_size = 64 },
            { icon = ICON_FILTER, icon_size = 64 },
        },
        subgroup = mods["-Hoochie_Data_Update"] and "air-filters-5" or "fluid-air-filtering-2",
        results = {}
    },

}
