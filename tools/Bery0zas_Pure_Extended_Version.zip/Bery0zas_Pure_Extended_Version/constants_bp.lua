------------------------------------------------------------------------------------------------------------------------
-- "-Bery0zas_Pure_Extended_Version" constants shared by data and control stages

local mod_name = "-Bery0zas_Pure_Extended_Version"
return
{
    graphics_path = "__" .. mod_name .. "__/graphics/",
    icon_path = "__" .. mod_name .. "__/graphics/icons/",
    entity_path = "__" .. mod_name .. "__/graphics/entity/",
    group_path = "__" .. mod_name .. "__/graphics/group/",
    technology_path = "__" .. mod_name .. "__/graphics/technology/",
    sound_path = "__" .. mod_name .. "__/sound/",
    mod_name = mod_name,
}

------------------------------------------------------------------------------------------------------------------------
--local mod = require("constants_bp")
--mod.graphics_path ..
--mod.icon_path ..
--mod.entity_path ..
--mod.group_path ..
--mod.technology_path ..
--mod.sound_path ..
--mod.mod_name ..